/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lambda_test;

import java.nio.channels.SelectionKey;

/**
 *
 * @author shashankgoud
 */
public class Lambda_AIC_Test {
    
    public void cancelkey(SelectionKey key)
    {
    
        Runnable r = new Runnable(){
        public void run()
        {
        
            key.cancel();
        
        }
        };
    
    }
    
    
}
