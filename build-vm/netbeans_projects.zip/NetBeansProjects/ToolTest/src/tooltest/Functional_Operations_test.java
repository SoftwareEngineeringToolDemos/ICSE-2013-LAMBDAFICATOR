/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tooltest;

/**
 *
 * @author vagrant
 */
public class Functional_Operations_test {
    
    public int getNumberOfErrors()
    {
        int count = 0;
        for(Elementrule rule : getRules())
        {
            if(rule.hasErrors())
                    {
                        count+=rule.getErrors().size();
                    }
        }
        return count;
    }
    
}