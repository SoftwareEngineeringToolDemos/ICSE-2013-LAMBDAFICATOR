/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lambda_test;

/**
 *
 * @author shashankgoud
 */
public class Lambda_Functional_Test {
    
    public int getNumberOfErrors()
    {
        int count =0;
        for(Elementrule rule:getRules())
        {
            if(rule.hasErrors())
            {
                count+=rule.getErrors().size();
            
            }
        
        }
         return count;
    }
    
    
}
